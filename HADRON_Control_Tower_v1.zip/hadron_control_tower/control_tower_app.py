"""
HADRON Control Tower — standalone dashboard.

Run:
    python control_tower_app.py

It expects the existing HADRON Flask API on http://127.0.0.1:5000.
If the API is unavailable, the dashboard still loads with demo records.
"""

import os
from flask import Flask, jsonify, render_template, request
import requests

app = Flask(__name__, template_folder="control_tower/templates",
            static_folder="control_tower/static")

HADRON_API = os.getenv("HADRON_API_URL", "http://127.0.0.1:5000")
TIMEOUT = int(os.getenv("HADRON_API_TIMEOUT", "120"))

DEMO_REQUESTS = [
    {
        "sys_id": "PR9023",
        "number": "PR-9023",
        "customer_name": "Google",
        "service_product_name": "Enterprise AI Transformation",
        "status": "ANALYZING",
        "commercial_objective": "Quantize AI models of Google",
        "additional_context": "Minimize size of upcoming Gemini Models",
    },
    {
        "sys_id": "PR9024",
        "number": "PR-9024",
        "customer_name": "Acme",
        "service_product_name": "Cloud Migration",
        "status": "READY",
        "commercial_objective": "Evaluate migration proposal",
        "additional_context": "",
    },
    {
        "sys_id": "PR9025",
        "number": "PR-9025",
        "customer_name": "BMW",
        "service_product_name": "AI Platform",
        "status": "AT RISK",
        "commercial_objective": "Build enterprise AI platform",
        "additional_context": "",
    },
]


@app.get("/")
def index():
    return render_template("index.html", api=HADRON_API)


@app.get("/api/requests")
def requests_list():
    # The demo endpoint intentionally mirrors the current ServiceNow
    # Pricing Request business shape. Once the table name is confirmed,
    # replace this with ServiceNowClient().query(...).
    return jsonify({
        "requests": DEMO_REQUESTS,
        "source": "demo",
    })


@app.post("/api/analyze")
def analyze():
    payload = request.get_json(force=True)
    required = ["customer_name", "service_product_name", "commercial_objective"]
    missing = [k for k in required if not payload.get(k)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    try:
        response = requests.post(
            f"{HADRON_API.rstrip('/')}/hadron/analyze",
            json=payload,
            timeout=TIMEOUT,
        )
        return (response.content, response.status_code,
                {"Content-Type": response.headers.get("Content-Type", "application/json")})
    except requests.RequestException as exc:
        return jsonify({
            "error": "HADRON API unavailable",
            "detail": str(exc),
            "hint": "Start the existing app.py on port 5000.",
        }), 502


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)
