let requests = [];
let selected = null;

const $ = id => document.getElementById(id);
const money = n => n == null || Number.isNaN(Number(n)) ? "—" :
  "$" + Number(n).toLocaleString(undefined,{maximumFractionDigits:0});

async function loadRequests(){
  const r = await fetch("/api/requests");
  const data = await r.json();
  requests = data.requests || [];
  renderRequests();
  if(requests.length) selectRequest(requests[0].sys_id);
}

function renderRequests(){
  $("requestList").innerHTML = requests.map(r => `
    <div class="request ${selected?.sys_id===r.sys_id?'selected':''}" onclick="selectRequest('${r.sys_id}')">
      <div class="req-top"><span class="req-number">${r.number}</span><span class="status ${r.status==='AT RISK'?'risk':r.status==='READY'?'ready':''}">${r.status}</span></div>
      <div class="req-name">${r.customer_name}</div>
      <div class="req-service">${r.service_product_name}</div>
    </div>`).join("");
}

function selectRequest(id){
  selected = requests.find(r=>r.sys_id===id);
  renderRequests();
  $("emptyState").classList.add("hidden");
  $("detail").classList.remove("hidden");
  $("detailNumber").textContent=selected.number;
  $("detailTitle").textContent=selected.customer_name+" — "+selected.service_product_name;
  $("detailObjective").textContent=selected.commercial_objective;
  $("detailStatus").textContent=selected.status;
  $("detailStatus").className="status "+(selected.status==="AT RISK"?"risk":selected.status==="READY"?"ready":"");
  $("summary").textContent="No current HADRON run loaded for this opportunity.";
  $("offerRange").textContent="—";
  $("metrics").innerHTML="";
  $("offers").innerHTML="";
  $("risks").innerHTML="";
}

function buildPayload(r){
  return {
    customer_name:r.customer_name,
    service_product_name:r.service_product_name,
    commercial_objective:r.commercial_objective,
    additional_context:r.additional_context||"",
    record_sys_id:r.sys_id
  };
}

function renderResult(data){
  const offers=data.offer_set||[];
  const prices=offers.map(o=>Number(o.price)).filter(Number.isFinite);
  const econ = typeof data.internal_economics==="string" ? JSON.parse(data.internal_economics||"{}") : (data.internal_economics||{});
  const low=prices.length?Math.min(...prices):econ.minimum_viable_price;
  const high=prices.length?Math.max(...prices):null;

  $("offerRange").textContent = high ? `${money(low)} — ${money(high)}` : money(low);
  $("summary").textContent = data.executive_summary || "Analysis completed. Review the evidence, scenarios and risks below.";

  $("metrics").innerHTML = [
    ["Minimum viable price", money(econ.minimum_viable_price)],
    ["Estimated cost", money(econ.estimated_cost)],
    ["Target margin", econ.target_margin != null ? (Number(econ.target_margin)*100).toFixed(1)+"%" : "—"],
    ["Confidence", data.confidence != null ? (Number(data.confidence)*100).toFixed(0)+"%" : "—"]
  ].map(x=>`<div class="metric"><span>${x[0]}</span><strong>${x[1]}</strong></div>`).join("");

  $("offers").innerHTML = offers.length ? offers.map(o=>`
    <div class="offer">
      <div class="offer-head"><span>${o.name}</span><span class="offer-price">${money(o.price)}</span></div>
      <div class="muted">${o.scope||""} · ${o.term_months||"—"} months · margin ${o.expected_margin!=null?(Number(o.expected_margin)*100).toFixed(1)+"%":"—"}</div>
    </div>`).join("") : '<div class="muted">No offer scenarios returned.</div>';

  const risks=data.risks||[];
  $("risks").innerHTML=risks.length ? risks.map(r=>`
    <div class="risk ${r.severity==='HIGH'?'high':''}">
      <strong>${r.title||r.type}</strong><div class="muted">${r.description||""}</div>
    </div>`).join("") : '<div class="muted">No risk signals returned.</div>';
}

async function runAnalysis(){
  if(!selected)return;
  $("runBtn").disabled=true; $("runBtn").textContent="Running HADRON…";
  try{
    const res=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(buildPayload(selected))});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error||"Analysis failed");
    renderResult(data);
  }catch(e){
    $("summary").textContent=e.message;
  }finally{
    $("runBtn").disabled=false; $("runBtn").textContent="Run HADRON analysis";
  }
}

$("runBtn").onclick=runAnalysis;
$("refreshBtn").onclick=loadRequests;
$("newBtn").onclick=()=>$("modal").classList.remove("hidden");
$("closeModal").onclick=()=>$("modal").classList.add("hidden");
$("createBtn").onclick=async()=>{
  const r={sys_id:"LOCAL-"+Date.now(),number:"PR-"+Math.floor(9000+Math.random()*999),
    customer_name:$("fCustomer").value,service_product_name:$("fService").value,
    commercial_objective:$("fObjective").value,additional_context:$("fContext").value,status:"ANALYZING"};
  requests.unshift(r); selected=r; renderRequests(); selectRequest(r.sys_id); $("modal").classList.add("hidden"); await runAnalysis();
};
loadRequests();
