# HADRON Control Tower — first vertical slice

This is the business-facing Control Tower shell for the existing HADRON Python engine.

## Run it

From the repository root:

```bash
# existing HADRON API
./venv/bin/python app.py

# in another terminal
./venv/bin/python control_tower_app.py
```

Open:

http://127.0.0.1:5050

## What is real

- The dashboard calls the existing `/hadron/analyze` endpoint.
- The returned `offer_set`, `internal_economics`, `risks`, `confidence`, and `executive_summary` are rendered into the Control Tower.
- The UI is deliberately organized around the commercial decision: offer range, economics, scenarios and risk.

## What is still a demo

`/api/requests` currently returns the three Pricing Request examples from the current Control Tower concept.

The next integration step is to replace that endpoint with the existing `ServiceNowClient.query()` against the actual Pricing Request table name. Do not guess that table name; read it from the ServiceNow app/table metadata or `.env`.

## Architecture

ServiceNow Pricing Request
        |
        v
HADRON orchestration API :5000
        |
        v
Control Tower UI :5050

The UI is intentionally separated from the calculation engine so the pricing logic remains testable.
